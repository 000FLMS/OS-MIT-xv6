#include "kernel/types.h"
#include "kernel/param.h"
#include "user/user.h"


int
main(int argc, char *argv[])
{
  if(argc < 2){
    fprintf(2, "Usage: xargs command args...\n");
    exit(1);
  }
  
  char buf[512], *xargv[MAXARG], *p;
  int flag = 0, xargc = 0, start_argc = 0;
  p = buf;
  
  
  for (int i = 1; i<argc; i++){
    xargv[xargc++] = argv[i];
    start_argc++;
  }
  
  for(int i = 0;read(0, &buf[i], 1) == 1;i++){
    if(xargc >= MAXARG){
      fprintf(2, "Too many args...\n");
      exit(1);
    }
    
    if(buf[i] == '\n'){
        buf[i] = 0;
        if(flag){
          xargv[xargc++] = p;
          if(fork()== 0){
            exec(argv[1], xargv);
          }
          wait(0);
          xargc = start_argc;
          i = 0;
          continue;
        }
        flag = 0;
        
    }
    else if(buf[i] == ' '){
      buf[i] = 0;
      if(flag)
        xargv[xargc++] = p;
      flag = 0;
    }
    else{
      if(flag == 0)
        p = &buf[i];
      flag = 1;
    }
    
  }
  
  exit(0);
}
