#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{

  if(argc != 1){
    fprintf(2, "Usage: pingpong...\n");
    exit(1);
  }

  int pipe1[2], pipe2[2];
  int pid;
  char buf[10];
  
  pipe(pipe1);
  pipe(pipe2);
  
  if(fork() == 0) {
    pid = getpid(); 
    read(pipe1[0], buf, sizeof(buf));
    fprintf(1,"%d: received %s\n", pid, buf);
    write(pipe2[1], "pong", sizeof("pong"));
    close(pipe2[1]);
  } 
  else {
    pid = getpid();
    write(pipe1[1], "ping", sizeof("ping"));
    close(pipe1[1]);
    read(pipe2[0], buf, sizeof(buf));
    fprintf(1,"%d: received %s\n", pid, buf);
    close(pipe1[0]);
    close(pipe2[0]);
  }
  exit(0);
}
