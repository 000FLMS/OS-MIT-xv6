#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


void prime_process(int * pipe_left, int* pipe_right);

int 
main(int argc, char *argv[])
{
  if (argc != 1){
    fprintf(2, "Usage: prime...\n");
    exit(1);
  }
  
  int pipe_left[2], pipe_right[2];
  pipe(pipe_left);
  
  
  for(int i = 2; i<=35;i++)
    write(pipe_left[1], &i, sizeof(i));
  close(pipe_left[1]);
  prime_process(pipe_left, pipe_right);
  
  wait(0);
  
  exit(0);
}


void
prime_process(int * pipe_left, int* pipe_right){
  int prime_num = 0, tmp = -1;
  
  if (fork() == 0){
    pipe(pipe_right);
    for(int i = 0; read(pipe_left[0], &tmp, sizeof(tmp)) != 0 ; i++){
      if(i  == 0){
        prime_num = tmp;
        printf("prime %d\n", prime_num);
      }
      else if(tmp % prime_num != 0) 
        write(pipe_right[1], &tmp, sizeof(tmp));
    }
    
    close(pipe_left[0]);
    
    if(prime_num != 0){
      close(pipe_right[1]);
      prime_process(pipe_right, pipe_left);
      wait(0);
    } 
  }
  
  return;
}




